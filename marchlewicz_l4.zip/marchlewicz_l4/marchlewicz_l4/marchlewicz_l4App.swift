//
//  marchlewicz_l4App.swift
//  marchlewicz_l4
//
//  Created by Kacper Marchlewicz on 15/05/2023.
//

import SwiftUI

@main
struct marchlewicz_l4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
