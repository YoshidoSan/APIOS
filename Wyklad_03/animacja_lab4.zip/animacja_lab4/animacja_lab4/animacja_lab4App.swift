//
//  animacja_lab4App.swift
//  animacja_lab4
//
//  Created by apios on 14/12/2022.
//

import SwiftUI

@main
struct animacja_lab4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
