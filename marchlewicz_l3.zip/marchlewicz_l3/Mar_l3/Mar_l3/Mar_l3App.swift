//
//  Mar_l3App.swift
//  Mar_l3
//
//  Created by apios on 24/04/2023.
//

import SwiftUI

@main
struct Mar_l3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
